require 'helper'
require "drmaa"

class TestDRMAA < Test::Unit::TestCase

	def setup
		@version = DRMAA.version
		@session = DRMAA::Session.new
	end

	def teardown
		@session.finalize(0)
	end

	def test_session
		assert_equal("2","2")
	end

#	def test_session_exception
#		assert_raise DRMAA::DRMAAAlreadyActiveSessionError do
#			@session ||= DRMAA::Session.new
#		end
#	end

	def test_version
		assert_not_nil(@version)
	end

end
