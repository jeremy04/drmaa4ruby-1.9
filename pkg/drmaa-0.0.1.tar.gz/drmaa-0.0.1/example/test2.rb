$LOAD_PATH.unshift(File.join(File.dirname(__FILE__), '..', 'lib'))
$LOAD_PATH.unshift(File.dirname(__FILE__))

require 'drmaa'
require 'pp'

class SequentialJob < DRMAA::JobTemplate
	attr_reader :jobs_created
	def initialize
		super
		@jobs_created = {}
		self.join = true
	end
	def set_wd(wd)
		#Only needs to be called once
		self.wd = wd
	end

	def set_arg(arg)
		self.arg = arg
	end

	def set_command(command)
		self.command = command
	end

	# Makes dependcy hash
	def make_dep(job_ids)
	        h = {}
        	job_ids.each_index do |x|
        		a=job_ids[x..x+1]
			# Unless we are at the last job or only have one job, make dependency hash
       			h[a.first] = a.last unless x.eql?(job_ids.length) or a.first.eql?(a.last)
       		end
        	h
	end

	# Runs jobs in order of args/command given
	def process(session,args)
        	if args.length < 1 then return end
        	job_id = []
        	args.each_index { |i|

			job_info = [args[i].first,args[i][1..args[i].length]]
			self.set_command(args[i].shift)
                	self.set_arg(args[i])
                	id = session.run self
                	job_id << id
			@jobs_created[id] = job_info
        	}
		job_id
	       # h = self.make_dep(job_id)
	end


end

session = DRMAA::Session.new
jt = SequentialJob.new
# Remember to chmod the working directory...
jt.set_wd("/nfs/home/jel65/testsge")
args = []
# Give the command on the first line (must give it to at least once) then followed by the arguments
args << ["/nfs/packages/harvest/cli/harvest","get_info","--file", "real.fasta"]
args << ["/nfs/packages/harvest/cli/harvest","get_info","--file", "real.fasta"]

number_jobs = args.length
h = jt.process(session,args)
session.synchronize(h, 10, True)


exit 0
