$LOAD_PATH.unshift(File.join(File.dirname(__FILE__), '..', 'lib'))
$LOAD_PATH.unshift(File.dirname(__FILE__))

require 'drmaa'
require 'pp'

class SequentialJob < DRMAA::JobTemplate
      attr_accessor :jobs_created, :job_id, :dep_hash
      def initialize
              super
              @jobs_created = {}
              self.join = true
      end
      def set_wd(wd)
              #Only needs to be called once
              self.wd = wd
      end

			def set_jobs(job)
				@job_id = job
			end
				
      def number_jobs
	      @job_id.length
      end

      def set_arg(arg)
              self.arg = arg
      end

      def set_command(command)
              self.command = command
      end
			
      def set_core(core)
              pp "Number of slots set: #{core}"
              self.native = "-pe openmpi #{core}"
      end	
      # Makes dependcy hash
      def make_dep(job_ids)
              h = {}
              job_ids.each_index do |x|
                      a=job_ids[x..x+1]
                      # Unless we are at the last job or only have one job, make dependency hash
                      h[a.first] = a.last unless x.eql?(job_ids.length) or a.first.eql?(a.last)
              end
              @dep_hash = h

      end

      # Runs jobs in order of args/command given
      def process(session,args)
              if args.length < 1 then return end
              @job_id = []
							
              args.each_index { |i|
                      job_info = [args[i].first,args[i][1..args[i].length]]
                      self.set_command(args[i].shift)
		      begin
                      	self.set_arg(args[i])
		      rescue DRMAA::DRMAAInvalidAttributeValueError
		        pp "invalid attribute.. whatever..."
		      end
                      id = session.run self
                      if i.eql?(0) and args.length > 1 then 
			pp "Holding"
                        pp i
                	self.hold = true 
		      end
                      @job_id << id
                      @jobs_created[id] = job_info
              }

              self.make_dep(@job_id)
      end
end


session = DRMAA::Session.new
jt = SequentialJob.new
# Remember to chmod the working directory...
jt.set_wd("/nfs/home/jel65/testsge")
args = []
# Give the command on the first line (must give it to at least once) then followed by the arguments
args << ["/nfs/packages/harvest/cli/harvest","get_info","--file", "real.fasta"]
args << ["/nfs/packages/harvest/cli/harvest","get_info","--file", "real.fasta"]
args << ["/nfs/packages/harvest/cli/harvest","get_info","--file", "real.fasta"]

number_jobs = args.length
jt.process(session,args)
time = 0
jt.jobs_created.each { |j|

				begin
					start = Time.new.to_i
					pp "checking #{j[0]}"
					info = session.wait(j[0])
					
					
					if info.nil? then
						pp "info is nil.."
						pp "This could mean anything really."
						next
					end
					job = info.job
					finish = Time.new.to_i
				rescue DRMAA::DRMAAInvalidJobError
					time+=1
					pp "DRMAA INVALID JOB ID ERROR"
					break
				end

				pp "Got something back..#{info.job}..lets see.."
				if jt.dep_hash.has_key?(job)
					session.release(jt.dep_hash[job])
				end
				if info.wifexited?
					puts job + " returned with " + info.wexitstatus.to_s
					puts "Job parameters:"
					pp jt.jobs_created[job]
					time+=1
				elsif info.wifaborted?			 
					puts job + " aborted"
					puts "Job parameters:"
					pp jt.jobs_created[job]
					time+=1
				elsif info.wifsignaled?
					time+=1
					puts job + " died from " + info.wtermsig
				end

			}


exit 0
