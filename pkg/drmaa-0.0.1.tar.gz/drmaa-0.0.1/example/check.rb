require 'drmaa'
require 'pp'
s = ARGV[0]


session = DRMAA::Session.new
5.times do
info = session.wait(s,20)
 
 if info.job.wifexited?
	puts "FINISHED"
 else
	pp info.job
 end

end
